<!DOCTYPE html>
<!--

Requisitos:

1.- Debemos generar una clave de 4 colores aleatorios no repetidos.
2.- Debemos poder mostrar la clave por pantalla.
3.- Implementar un formulario con selects para que el usuario pueda elegir los colores que quiera
4.- Ser capaces de mostrar los colores y las posiciones acertadas
5.- Ir poder mostrando las sucesivas jugadas que efectúa el ususario.
6.- Establecer un límite de jugadas.
7.- Mostrar las distintas jugadas por pantalla
8.- En caso de que el usuario acierte, remitirlo a la pantalla de fin.

-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="jugar.php" method="POST">

            <h2>Dale al botón para empezar la partida</h2>
            <input type="submit" value="Empezar" name="submit">
        </form>
    </body>
</html>
