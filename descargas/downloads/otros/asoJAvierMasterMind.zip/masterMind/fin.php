<html>
    <head>
        <title></title>
    </head>
    <body>

        <h1><?php
            echo $_GET['mensaje'];
            ?></h1>




    </body>
</html>
